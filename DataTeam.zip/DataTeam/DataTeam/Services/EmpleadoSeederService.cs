using DataTeam.Models;
using System.Text;

namespace DataTeam.Services;

public class EmpleadoSeederService
{
    private readonly ICsvService _csvService;
    private readonly ILogger<EmpleadoSeederService> _logger;
    private readonly IWebHostEnvironment _environment;

    public EmpleadoSeederService(
        ICsvService csvService, 
        ILogger<EmpleadoSeederService> logger,
        IWebHostEnvironment environment)
    {
        _csvService = csvService;
        _logger = logger;
        _environment = environment;
    }

    public async Task SeedEmpleadosAsync()
    {
        try
        {
            // Verificar si el archivo CSV existe y tiene datos
            var csvPath = Path.Combine(_environment.ContentRootPath, "DATE-TEAM-1.csv");
            var csvPathAlt = Path.Combine(_environment.ContentRootPath, "DATE TEAM 1.1.csv");

            var archivoExiste = File.Exists(csvPath) || File.Exists(csvPathAlt);

            if (!archivoExiste)
            {
                _logger.LogWarning("⚠️ No se encontró ningún archivo CSV. Creando archivo vacío...");
                // Crear un archivo CSV vacío con headers
                await CrearArchivoVacioAsync();
                return;
            }

            // Intentar leer empleados
            var empleadosExistentes = await _csvService.LeerEmpleadosAsync();

            if (empleadosExistentes.Any())
            {
                _logger.LogInformation($"✅ CSV ya contiene {empleadosExistentes.Count} empleados. Sistema listo para usar.");
                return;
            }

            _logger.LogInformation("ℹ️ El archivo CSV existe pero está vacío o sin datos válidos.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error al verificar datos de empleados");
        }
    }

    private async Task CrearArchivoVacioAsync()
    {
        try
        {
            var csvPath = Path.Combine(_environment.ContentRootPath, "DATE TEAM 1.1.csv");

            var headers = new StringBuilder();
            headers.AppendLine(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;"); // Línea 1
            headers.AppendLine(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;"); // Línea 2
            headers.AppendLine(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;"); // Línea 3
            headers.AppendLine(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;"); // Línea 4
            headers.AppendLine(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;"); // Línea 5
            headers.AppendLine("Cédula;Nombre;Correo;Nombre del Cargo Oficial;Desarrollo;Rol;% participación;Célula;Lider;Empresa;Udemy;ARL;Ciudad;Fecha de Cumpleaños;Mes Cumple;Dirección;Barrio;Telefono Fijo;Tel Celular;Contacto adicional;N° contacto adicional;Fecha Ingreso;N° Renovaciones;Fecha de renovación Actual;Fecha Vto Contrato;Inducción;Plan de entrenamiento;Fecha Vto PP;PP;Visual;Estado;VAC - Inicio;VAC - Final;VAC - Reintegro;Mes vacaciones;Saldo de vacaciones para 2025;Días tomados 2025;Días pte por disfrutar 2025;Horario de Trabajo;Observaciones");

            await File.WriteAllTextAsync(csvPath, headers.ToString(), Encoding.UTF8);
            _logger.LogInformation($"✅ Archivo CSV creado en: {csvPath}");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al crear archivo CSV vacío");
        }
    }
}
