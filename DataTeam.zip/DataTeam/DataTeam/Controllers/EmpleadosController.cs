using DataTeam.Models;
using DataTeam.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DataTeam.Controllers;

[Authorize]
public class EmpleadosController : Controller
{
    private readonly ICsvService _csvService;
    private readonly IAuditoriaService _auditoriaService;
    private readonly ILogger<EmpleadosController> _logger;

    public EmpleadosController(
        ICsvService csvService,
        IAuditoriaService auditoriaService,
        ILogger<EmpleadosController> logger)
    {
        _csvService = csvService;
        _auditoriaService = auditoriaService;
        _logger = logger;
    }

    // GET: Empleados
    public async Task<IActionResult> Index(int pagina = 1, string? filtro = null, string? celula = null)
    {
        try
        {
            const int ITEMS_POR_PAGINA = 50;
            var (empleados, total) = await _csvService.ObtenerEmpleadosPaginadosAsync(pagina, ITEMS_POR_PAGINA, filtro, celula);

            // Obtener lista de células para el filtro
            var celulas = await _csvService.ObtenerCelulasUnicasAsync();

            ViewBag.PaginaActual = pagina;
            ViewBag.TotalPaginas = (int)Math.Ceiling((double)total / ITEMS_POR_PAGINA);
            ViewBag.TotalEmpleados = total;
            ViewBag.Filtro = filtro;
            ViewBag.CelulaSeleccionada = celula;
            ViewBag.Celulas = celulas;

            return View(empleados);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al cargar la lista de empleados");
            TempData["Error"] = "Error al cargar los empleados del archivo CSV";
            return View(new List<EmpleadoDataTeam>());
        }
    }

    // GET: Empleados/Details/cedula
    public async Task<IActionResult> Details(string? id)
    {
        if (string.IsNullOrWhiteSpace(id))
        {
            TempData["Error"] = "Debe seleccionar un empleado de la tabla para ver sus detalles.";
            return RedirectToAction(nameof(Index));
        }

        try
        {
            var empleado = await _csvService.ObtenerEmpleadoPorCedulaAsync(id);
            if (empleado == null)
            {
                TempData["Error"] = $"No se encontró el empleado con cédula {id}";
                return RedirectToAction(nameof(Index));
            }

            return View(empleado);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al cargar empleado {Cedula}", id);
            TempData["Error"] = "Error al cargar los detalles del empleado";
            return RedirectToAction(nameof(Index));
        }
    }

    // GET: Empleados/Create
    [Authorize(Roles = "SuperAdmin,Admin")]
    public IActionResult Create()
    {
        return View(new EmpleadoDataTeam());
    }

    // POST: Empleados/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = "SuperAdmin,Admin")]
    public async Task<IActionResult> Create(EmpleadoDataTeam empleado)
    {
        try
        {
            await _csvService.AgregarEmpleadoAsync(empleado);

            // Registrar en auditoría
            await _auditoriaService.RegistrarCambioAsync(
                entidad: "EmpleadoDataTeam",
                entidadId: 0, // No hay ID numérico en CSV
                accion: "Crear",
                usuario: User.Identity?.Name ?? "Anónimo",
                valoresAnteriores: null,
                valoresNuevos: $"Nombre: {empleado.Nombre}, Cédula: {empleado.Cedula}, Correo: {empleado.Correo}",
                direccionIP: HttpContext.Connection.RemoteIpAddress?.ToString() ?? "N/A"
            );

            TempData["Success"] = $"Empleado {empleado.Nombre} creado exitosamente";
            return RedirectToAction(nameof(Index));
        }
        catch (InvalidOperationException ex)
        {
            ModelState.AddModelError("", ex.Message);
            return View(empleado);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al crear empleado");
            ModelState.AddModelError("", "Error al crear el empleado en el archivo CSV");
            return View(empleado);
        }
    }

    // GET: Empleados/Edit/cedula
    [Authorize(Roles = "SuperAdmin,Admin")]
    public async Task<IActionResult> Edit(string? id)
    {
        if (string.IsNullOrWhiteSpace(id))
        {
            TempData["Error"] = "Debe seleccionar un empleado de la tabla para editar.";
            return RedirectToAction(nameof(Index));
        }

        try
        {
            var empleado = await _csvService.ObtenerEmpleadoPorCedulaAsync(id);
            if (empleado == null)
            {
                TempData["Error"] = $"No se encontró el empleado con cédula {id}";
                return RedirectToAction(nameof(Index));
            }

            return View(empleado);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al cargar empleado {Cedula} para edición", id);
            TempData["Error"] = "Error al cargar el empleado para edición";
            return RedirectToAction(nameof(Index));
        }
    }

    // POST: Empleados/Edit/cedula
    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = "SuperAdmin,Admin")]
    public async Task<IActionResult> Edit(string id, EmpleadoDataTeam empleado)
    {
        if (id != empleado.Cedula)
        {
            return NotFound();
        }

        try
        {
            var empleadoAnterior = await _csvService.ObtenerEmpleadoPorCedulaAsync(id);

            await _csvService.ActualizarEmpleadoAsync(empleado);

            // Registrar en auditoría
            await _auditoriaService.RegistrarCambioAsync(
                entidad: "EmpleadoDataTeam",
                entidadId: 0, // No hay ID numérico en CSV
                accion: "Editar",
                usuario: User.Identity?.Name ?? "Anónimo",
                valoresAnteriores: $"Nombre: {empleadoAnterior?.Nombre}, Estado: {empleadoAnterior?.Estado}, Célula: {empleadoAnterior?.Celula}",
                valoresNuevos: $"Nombre: {empleado.Nombre}, Estado: {empleado.Estado}, Célula: {empleado.Celula}",
                direccionIP: HttpContext.Connection.RemoteIpAddress?.ToString() ?? "N/A"
            );

            TempData["Success"] = $"Empleado {empleado.Nombre} actualizado exitosamente";
            return RedirectToAction(nameof(Index));
        }
        catch (InvalidOperationException ex)
        {
            ModelState.AddModelError("", ex.Message);
            return View(empleado);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error al actualizar empleado {id}");
            ModelState.AddModelError("", "Error al actualizar el empleado en el archivo CSV");
            return View(empleado);
        }
    }

    // GET: Empleados/ExportarCsv
    public async Task<IActionResult> ExportarCsv()
    {
        try
        {
            var csvPath = Path.Combine(Directory.GetCurrentDirectory(), "DATE TEAM 1.1.csv");

            if (!System.IO.File.Exists(csvPath))
            {
                return NotFound("Archivo CSV no encontrado");
            }

            var csvBytes = await System.IO.File.ReadAllBytesAsync(csvPath);
            return File(csvBytes, "text/csv", "DataTeam_Empleados.csv");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al exportar CSV");
            TempData["Error"] = "Error al exportar el archivo CSV";
            return RedirectToAction(nameof(Index));
        }
    }

    // GET: Empleados/Estadisticas
    public async Task<IActionResult> Estadisticas()
    {
        try
        {
            var empleados = await _csvService.LeerEmpleadosAsync();

            var stats = new
            {
                TotalEmpleados = empleados.Count,
                PorEstado = empleados.GroupBy(e => e.Estado).Select(g => new { Estado = g.Key ?? "Sin Estado", Cantidad = g.Count() }),
                PorCelula = empleados.GroupBy(e => e.Celula).Select(g => new { Celula = g.Key ?? "Sin Célula", Cantidad = g.Count() }),
                PorEmpresa = empleados.GroupBy(e => e.Empresa).Select(g => new { Empresa = g.Key ?? "Sin Empresa", Cantidad = g.Count() }),
                PorCiudad = empleados.GroupBy(e => e.Ciudad).Select(g => new { Ciudad = g.Key ?? "Sin Ciudad", Cantidad = g.Count() })
            };

            return View(stats);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al cargar estadísticas");
            TempData["Error"] = "Error al cargar las estadísticas";
            return RedirectToAction(nameof(Index));
        }
    }
}
